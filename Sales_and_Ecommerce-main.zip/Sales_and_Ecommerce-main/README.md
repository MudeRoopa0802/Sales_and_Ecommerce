# Sales_and_Ecommerce
You can find the dataset in this [link](https://drive.google.com/drive/folders/1ss5mJRN-eAdt99dmDA0ExVeR3u0mGE8u?usp=sharing) provided
